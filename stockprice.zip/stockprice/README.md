# Stock Analytics App

The Stock Analytics App is  allows users to analyze stock market data using financial API data. The app leverages OpenAI functions to provide insightful information about stock trends, historical data, and predictions. This README file will guide you through the process of setting up and running the Stock Analytics App on your local machine.

## Prerequisites

Before you proceed, make sure you have the following prerequisites installed on your system:

-   Python (version 3.6 or higher)
-   Django (version 3.x)
-   Pip (Python package manager)
-   Git (optional, for cloning the project repository)

## Installation

Follow these steps to install and run the Stock Analytics App:

1.  Clone the repository (Skip this step if you already have the project files):
    

    
    ```
    git clone https://gitlab.com/uttampatel2/stock_market_app.git
    ``` 
    or
    ```
    cd existing_repo git 
    remote add origin https://gitlab.com/uttampatel2/stock_market_app.git 
    git branch -M main 
    git push -uf origin main
    ```
    
2.  Change into the project directory:
    
    
    ```
    cd stock_market_app
    ``` 
    
3.  Create a virtual environment (optional but recommended):

    
    ```
    python -m venv venv
    ``` 
    
4.  Activate the virtual environment:
    
    -   For Windows:
 
        
        ```
        venv\Scripts\activate 
        ``` 
        
    -   For macOS and Linux:

        
        ```
        source venv/bin/activate
        ``` 
        
5.  Install the required Python packages:
    

    
    ```
    pip install -r requirements.txt
    ```
    
6.  Configure API keys:
    
    - create .env file 
    - add API like OPENAI_API_KEY="key" , YH_FINACEE_API="key"

7.  Perform database migration:
    
 
    
    ```
    python manage.py migrate
    ```
    

## Usage

Follow these steps to run the Stock Analytics App:

1.  Launch the development server:
    
    Copy code
    
    ```
    python manage.py runserver
    ``` 
    
2.  Open your web browser and navigate to `http://localhost:8000/` (or another specified port) to access the app.
    
5. Ask sample questions related to a company's financial metrics:
	
	1.  What is the current stock price of the company?
	2.  Can you provide the latest P/E ratio (Price-to-Earnings ratio) for the company?
	3.  What is the company's EBITDA (Earnings Before Interest, Taxes, Depreciation, and Amortization) for the last quarter?
	4.  How does the company's current stock price compare to its 52-week high and low?
	5.  What is the company's revenue growth rate for the past year?
	6.  Can you give an overview of the company's balance sheet and its total assets, liabilities, and shareholders' equity?
	7.  What is the company's dividend yield?
	8.  How does the company's net income compare to the same quarter last year?
	9.  What is the debt-to-equity ratio of the company?
	10.  What is the current market capitalization of the company?

