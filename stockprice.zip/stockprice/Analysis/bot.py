import openai
import json
import os
from dotenv import load_dotenv
import requests
from .stock_data import get_stock_financials , get_stock_news , get_stock_summary , get_stock_price_movment , get_stock_Income_Statement , get_stock_Statistics , get_compny_majorHoldersBreakdown , get_stock_esg_score , get_stock_earnings_histroy  , get_stock_indexTrend , get_stock_recommendation , get_stock_sentiments , get_stock_Balance_Sheet,get_stock_calendarEvents , get_stock_earningsTrend
from .functions_dec import function_descriptions

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
rapid_api_key = os.getenv("X-RapidAPI-Key")
smart_light_api_key = os.getenv("SMART_LIGHT_API_KEY")


def get_stock_movers():
    url = "https://morning-star.p.rapidapi.com/market/v2/get-movers"

    headers = {
        "X-RapidAPI-Key": rapid_api_key,
        "X-RapidAPI-Host": "morning-star.p.rapidapi.com"
    }
    
    response = requests.get(url, headers=headers)
    
    return response.json()


def function_call(ai_response):
    function_call = ai_response["choices"][0]["message"]["function_call"]
    function_name = function_call["name"]
    arguments = function_call["arguments"]
    if function_name == "get_stock_movers":
        return get_stock_movers()
    elif function_call == "get_stock_sentiments":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_sentiments(stock_symbol)
    elif function_name == "get_stock_news":
        stock_symbol = eval(arguments).get("company_name")
        return get_stock_news(stock_symbol)
    elif function_name == "get_stock_summary":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_summary(stock_symbol)
    elif function_name == "get_stock_financials":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_financials(stock_symbol)
    elif function_name == "get_stock_Statistics":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_Statistics(stock_symbol)
    elif function_name == "get_stock_price_movment":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_price_movment(stock_symbol)
    elif function_name == "get_stock_Income_Statement":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_Income_Statement(stock_symbol)
    elif function_name == "get_compny_majorHoldersBreakdown":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_compny_majorHoldersBreakdown(stock_symbol)
    elif function_name == "get_stock_Balance_Sheet":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_Balance_Sheet(stock_symbol)
    elif function_name == "get_stock_esg_score":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_esg_score(stock_symbol)
    elif function_name == "get_stock_recommendation":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_recommendation(stock_symbol)
    elif function_name == "get_stock_earnings_histroy":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_earnings_histroy(stock_symbol)
    elif function_name == "get_stock_indexTrend":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_indexTrend(stock_symbol)
    elif function_name == "get_stock_calendarEvents":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_calendarEvents(stock_symbol)
    elif function_name == "get_stock_earningsTrend":
        stock_symbol = eval(arguments).get("stock_symbol")
        return get_stock_earningsTrend(stock_symbol)
    else:
        return
        

def ask_function_calling(query):
    messages = [{"role": "user", "content": query}]

    try:
        response = openai.ChatCompletion.create(
            # model="gpt-4-0613",
            model="gpt-3.5-turbo-0613",
            messages=messages,
            functions = function_descriptions,
            function_call="auto"
        )

        print(response)
        i = 0

        while response["choices"][0]["finish_reason"] == "function_call" and i < 3:
            try:
                function_response = function_call(response)
            except Exception as e:
                print(e)
                return "Sorry, rewrite your query please! or some otherway you can ask me!"
            
            
            messages.append({
                "role": "function",
                "name": response["choices"][0]["message"]["function_call"]["name"],
                "content": json.dumps(function_response)
            })

            # print("messages: ", messages) 
        

            response = openai.ChatCompletion.create(
                # model="gpt-4-0613",
                model="gpt-3.5-turbo-16k",
                messages=messages,
                functions = function_descriptions,
                function_call="auto"
            )   

            print("response: ", response)
            i += 1
            # print("content: ", response["choices"][0]["message"]["content"])
        else:
            print("else content: ", response["choices"][0]["message"]["content"])
            return response["choices"][0]["message"]["content"]
    except Exception as e:
        print(e)
        return "you reached up API limit,\n please wait 1 minute!"

if __name__ == "__main__":

    # user_query = "give me news summary of wipro stock today?"
    # user_query = "what is the stock that has the biggest price movment today?"
    # user_query = """what is the stock that has the biggest price movment today 
    #                 and what are the latest news about stock that might case the price movements?"""
    # user_query = """what is the stock that has the biggest price movment today 
    #                 and what are the latest news about stock that might case the price movements?
    #                 please add record to airtable with the stock, news summary & price move."""

    # user_query = "give me Income Statement of adani stock?"
    user_query = "give me Income Statement of wipro stock?"
    # user_query = "give me current price of wipro stock?"
    # user_query = "give me 52 Week Range of adani stock?"
    # user_query = "give me P/E Ratio of wipro stock?"
    # user_query = "give me Market Cap of Balrampur Chini Mills stock?
    # user_query = "give me financials of Balrampur Chini Mills stock?"
    # user_query = "give me income sataments of wipro stock?"
    # user_query = "give me Statistics of wipro stock?"
    # user_query = "give me price movements of wipro stock?"
    # user_query = "give me Major Holders of wipro stock?"
    # user_query = "give me ESG score summary of wipro stock?"
    # user_query = "give me earnings History of wipro stock?"
    # user_query = "give me indexTrend of wipro stock?"


    ask_function_calling(user_query)