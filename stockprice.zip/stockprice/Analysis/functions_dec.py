function_descriptions = [
    {
        "name": "get_stock_price_movment",
        "description": "Get the stocks that has e.g. currency , regularMarketChangePercent , regularMarketChange , regularMarketPrice , regularMarketDayHigh , regularMarketDayLow , regularMarketVolume , regularMarketPreviousClose , regularMarketOpen, marketCap. "
        ,
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "this is a stock symbol from nseindia",
                }
            },
            "required": ["stock_symbol"],
        },
    },
    {
        "name": "get_stock_sentiments",
        "description": "get sentiment analysis of news for perticuler stock"
        ,
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "this is a stock name from nse india market",
                }
            },
            "required": ["stock_symbol"],
        },
    },
    {
        "name": "get_stock_movers",
        "description": "Get the stocks that has biggest price/volume moves, e.g. actives, gainers, losers, etc.",
        "parameters": {
            "type": "object",
            "properties": {
            },
        }
    },
    {
        "name": "get_stock_financials",
        "description": "Get the financials (e.g. CurrentPrice,Target Price, TargetHighPrice, TargetLowPrice, TargetMeanPrice, TargetMedianPrice, RecommendationMean, RecommendationKey, NumberofAnalystOpinions, TotalCash, TotalCashPerShare, EBITDA, TotalDebt, QuickRatio, CurrentRatio, TotalRevenue, DebttoEquity, RevenuePerShare, ReturnonAssets, ReturnonEquity, FreeCashflow, OperatingCashflow, EarningsGrowth, RevenueGrowth, GrossMargins, EBITDAMargins, OperatingMargins, Profit Margins) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_Statistics",
        "description": "Get the Statistics (e.g. maxage, priceHint, enterpriseValue, forwardPE, profitMargins, floatShares, sharesOutstanding, heldPercentInsiders, heldPercentInstitutions, beta, impliedSharesOutstanding, bookValue, priceToBookRatio, lastFiscalYearEnd, nextFiscalYearEnd, mostRecentQuarter, earningsQuarterlyGrowth, netIncomeToCommon, trailingEps, forwardEps, pegRatio, lastSplitFactor, lastSplitDate, enterpriseToRevenueRatio, enterpriseToEbitdaRatio, 52WeekChange, SandP52WeekChange, lastDividendValue, lastDividendDate ) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_Balance_Sheet",
        "description": "Get the Balance Sheet of a company or stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
     {
        "name": "get_stock_summary",
        "description": "Get the summary (Previous Close, Open, Bid, Ask, Day's Range, 52 Week Range, Volume, Avg. Volume, Market Cap, Beta (5Y Monthly), PE Ratio (TTM), EPS (TTM), Earnings Date, Forward Dividend & Yield, Ex-Dividend Date, 1y Target Est) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_Income_Statement",
        "description": "Get the Income Statement ( total_revenue, cost_of_revenue, gross_profit, sga_expenses, total_operating_expenses, operating_income, net_income) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_compny_majorHoldersBreakdown",
        "description": "Get the Major Holders Breakdown (insidersPercentHeld , institutionsPercentHeld , institutionsFloatPercentHeld , institutionsCount) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_esg_score",
        "description": "Get the esg score (totalEsg ,environmentScore, socialScore , governanceScore , peerGroup, peerEsgScorePerformance , peerGovernancePerformance , peerSocialPerformance , peerEnvironmentPerformance , peerHighestControversyPerformance , etc.) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_earnings_histroy",
        "description": "Get the earning histroy quarterly (EPS EST , EPS Actual , Difference , Surprise % ) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_indexTrend",
        "description": "Get the indexTrend(peg_ratio, periods, growth_rates) of a stock",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
    {
        "name": "get_stock_recommendation",
        # "description": "Get the recommendation of a stock and buy any stock or not OR SUGGESTION",
        "description": "Get the recommendation or suggestion FOR A STOCK based on input question",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
     {
        "name": "get_stock_news",
        "description": "Get all news (trending discussions or mentions) of company",
        "parameters": {
            "type": "object",
            "properties": {
                "company_name": {
                    "type": "string",
                    "description": "give a company name"
                },
            },
            "required": ["company_name"]
        }
    },
     {
        "name": "get_stock_calendarEvents",
        "description": "get the stock calendarEvents - like earnings dates, earnings average or low or high, revenue average or low or high ",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
     {
        "name": "get_stock_earningsTrend",
        "description": "get the stock like growth rates, earnings estimates, revenue estimates",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_symbol": {
                    "type": "string",
                    "description": "stock ticker from yahoo finance"
                },
            },
            "required": ["stock_symbol"]
        }
    },
]

# {
    #     "name": "get_stock_news",
    #     "description": "Get the latest news for a stock",
    #     "parameters": {
    #         "type": "object",
    #         "properties": {
    #             "performanceId": {
    #                 "type": "string",
    #                 "description": "id of the stock, which is referred as performanceID in the API"
    #             },
    #         },
    #         "required": ["performanceId"]
    #     }
    # },