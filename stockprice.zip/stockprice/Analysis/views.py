from django.shortcuts import render,HttpResponse
import json
from django.http import JsonResponse
from .bot import ask_function_calling
from django.views.decorators.csrf import csrf_exempt


# Create your views here.
def index(request):
    return render(request, 'index.html')

@csrf_exempt
def ask_question(request):
    try:
        data = json.loads(request.body)
        question = data.get('question', '')  # Provide a default value if 'question' is None

        # print(question)
        # Perform your logic to retrieve the response based on the question
        # Example response
        # print(question)
        response = ask_function_calling(question)
        try:
            response = response.replace("\n","<br>")
        except:
            response = response
        return HttpResponse(response)
    except (json.JSONDecodeError, KeyError):
        # Handle the error gracefully
        return JsonResponse({"error": "Invalid request data"}, status=400)
