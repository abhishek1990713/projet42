import requests
from dotenv import load_dotenv
import os
import json

load_dotenv()
rapid_api_key = os.getenv("X-RapidAPI-Key")
yh_api_key = os.getenv("YH_FINACEE_API")
news_api = os.getenv("NEWS_API")


def get_stock_Statistics(stock_symbol):
    """
    Get the statistics of a company
    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=defaultKeyStatistics"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    # Extract useful information
    result = data["quoteSummary"]["result"][0]["defaultKeyStatistics"]

    extracted_info = {
        "maxAge": result.get("maxAge", "N/A"),
        "priceHint": result.get("priceHint", {}).get("fmt", "N/A"),
        "enterpriseValue": result.get("enterpriseValue", {}).get("fmt", "N/A"),
        "forwardPE": result.get("forwardPE", {}).get("fmt", "N/A"),
        "profitMargins": result.get("profitMargins", {}).get("fmt", "N/A"),
        "floatShares": result.get("floatShares", {}).get("fmt", "N/A"),
        "sharesOutstanding": result.get("sharesOutstanding", {}).get("fmt", "N/A"),
        "heldPercentInsiders": result.get("heldPercentInsiders", {}).get("fmt", "N/A"),
        "heldPercentInstitutions": result.get("heldPercentInstitutions", {}).get("fmt", "N/A"),
        "beta": result.get("beta", {}).get("fmt", "N/A"),
        "impliedSharesOutstanding": result.get("impliedSharesOutstanding", {}).get("fmt", "N/A"),
        "bookValue": result.get("bookValue", {}).get("fmt", "N/A"),
        "priceToBookRatio": result.get("priceToBook", {}).get("fmt", "N/A"),
        "lastFiscalYearEnd": result.get("lastFiscalYearEnd", {}).get("fmt", "N/A"),
        "nextFiscalYearEnd": result.get("nextFiscalYearEnd", {}).get("fmt", "N/A"),
        "mostRecentQuarter": result.get("mostRecentQuarter", {}).get("fmt", "N/A"),
        "earningsQuarterlyGrowth": result.get("earningsQuarterlyGrowth", {}).get("fmt", "N/A"),
        "netIncomeToCommon": result.get("netIncomeToCommon", {}).get("fmt", "N/A"),
        "trailingEps": result.get("trailingEps", {}).get("fmt", "N/A"),
        "forwardEps": result.get("forwardEps", {}).get("fmt", "N/A"),
        "pegRatio": result.get("pegRatio", {}).get("fmt", "N/A"),
        "lastSplitFactor": result.get("lastSplitFactor", "N/A"),
        "lastSplitDate": result.get("lastSplitDate", {}).get("fmt", "N/A"),
        "enterpriseToRevenueRatio": result.get("enterpriseToRevenue", {}).get("fmt", "N/A"),
        "enterpriseToEbitdaRatio": result.get("enterpriseToEbitda", {}).get("fmt", "N/A"),
        "52WeekChange": result.get("52WeekChange", {}).get("fmt", "N/A"),
        "SandP52WeekChange": result.get("SandP52WeekChange", {}).get("fmt", "N/A"),
        "lastDividendValue": result.get("lastDividendValue", {}).get("fmt", "N/A"),
        "lastDividendDate": result.get("lastDividendDate", {}).get("fmt", "N/A")
    }

    json_data = json.dumps(extracted_info, indent=4)

    # Print the JSON string
    print(json_data)
    return json_data

def get_stock_news(symbol):
    url = f"https://newsapi.org/v2/everything?q={symbol}&apiKey={news_api}&sources=the-times-of-india,google-news-in,the-hindu&language=en"
    headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0;Win64) AppleWebkit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
        }

    response = requests.get(url, headers=headers)
    
    data = response.json()
    news = data["articles"][:10]    
    
    final_data = {}
    for index,data in enumerate(news):
        temp = {}
        temp['title'] = data['title']
        # temp['description'] = data['description']
        temp['url'] = data['url']
        final_data[str(index+1)] = temp
    print(final_data)
    
    return (final_data)
       
def get_stock_price_movment(stock_symbol):
    """
    Get the price movement of a stock
    like: currency, regularMarketChangePercent, regularMarketChange, regularMarketPrice, regularMarketDayHigh, regularMarketDayLow, regularMarketVolume, regularMarketPreviousClose, regularMarketOpen, marketCap
    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=price"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    # Extract useful information
    result = data["quoteSummary"]["result"][0]["price"]

    # Extracted information with fallback to None if key is missing
    currency = result.get("currency", None)
    regularMarketChangePercent = result.get("regularMarketChangePercent", {}).get("fmt", None)
    regularMarketChange = result.get("regularMarketChange", {}).get("fmt", None)
    regularMarketPrice = result.get("regularMarketPrice", {}).get("fmt", None)
    regularMarketDayHigh = result.get("regularMarketDayHigh", {}).get("fmt", None)
    regularMarketDayLow = result.get("regularMarketDayLow", {}).get("fmt", None)
    regularMarketVolume = result.get("regularMarketVolume", {}).get("fmt", None)
    regularMarketPreviousClose = result.get("regularMarketPreviousClose", {}).get("fmt", None)
    regularMarketOpen = result.get("regularMarketOpen", {}).get("fmt", None)
    marketCap = result.get("marketCap", {}).get("fmt", None)

    # Extracted information
    data = {
        "currency": currency,
        "regularMarketChangePercent": regularMarketChangePercent,
        "regularMarketChange": regularMarketChange,
        "regularMarketPrice": regularMarketPrice,
        "regularMarketDayHigh": regularMarketDayHigh,
        "regularMarketDayLow": regularMarketDayLow,
        "regularMarketVolume": regularMarketVolume,
        "regularMarketPreviousClose": regularMarketPreviousClose,
        "regularMarketOpen": regularMarketOpen,
        "marketCap": marketCap
    }

    # Convert to JSON string
    json_data = json.dumps(data, indent=4)

    # Return the JSON string
    return json_data

def get_stock_summary(stock_symbol):
    """
    A function to get the summary of a stock like:
    - Previous Close, Open, Bid, Ask, Day's Range, 52 Week Range, Volume, Avg. Volume, Market Cap, Beta (5Y Monthly), PE Ratio (TTM), EPS (TTM), Earnings Date, Forward Dividend & Yield, Ex-Dividend Date, 1y Target Est
    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=summaryDetail"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }
    
    response = requests.request("GET", url, headers=headers)
    json_data = response.json()
    result = json_data['quoteSummary']['result'][0]['summaryDetail']

    # Extracted information with fallback to 'N/A' if key is missing
    previous_close = result.get('previousClose', {}).get('fmt', 'N/A')
    market_cap = result.get('marketCap', {}).get('fmt', 'N/A')
    open_price = result.get('open', {}).get('fmt', 'N/A')
    day_low = result.get('dayLow', {}).get('fmt', 'N/A')
    day_high = result.get('dayHigh', {}).get('fmt', 'N/A')
    bid_price = result.get('bid', {}).get('fmt', 'N/A')
    ask_price = result.get('ask', {}).get('fmt', 'N/A')
    day_range = f"{result.get('dayLow', {}).get('fmt', 'N/A')} - {result.get('dayHigh', {}).get('fmt', 'N/A')}"
    fifty_two_week_range = f"{result.get('fiftyTwoWeekLow', {}).get('fmt', 'N/A')} - {result.get('fiftyTwoWeekHigh', {}).get('fmt', 'N/A')}"
    volume = result.get('volume', {}).get('longFmt', 'N/A')
    average_volume = result.get('averageVolume', {}).get('longFmt', 'N/A')
    pe_ratio_ttm = result.get('trailingPE', {}).get('fmt', 'N/A')
    beta = result.get('beta', {}).get('fmt', 'N/A')
    eps_ttm = result.get('trailingEps', {}).get('fmt', 'N/A')
    earning_date = result.get('earningsDate', {}).get('fmt', 'N/A')
    forward_dividend_yield = result.get('trailingAnnualDividendYield', {}).get('fmt', 'N/A')
    forward_dividend = result.get('trailingAnnualDividendRate', {}).get('fmt', 'N/A')
    exDividend_date = result.get('exDividendDate', {}).get('fmt', 'N/A')
    target_est = result.get('targetMeanPrice', {}).get('fmt', 'N/A')

    # Create a dictionary with the extracted data
    data_dict = {
        "PreviousClose": previous_close,
        "MarketCap": market_cap,
        "Open": open_price,
        "DayLow": day_low,
        "DayHigh": day_high,
        "Bid": bid_price,
        "Ask": ask_price,
        "Day'sRange": day_range,
        "52WeekRange": fifty_two_week_range,
        "Volume": volume,
        "Avg.Volume": average_volume,
        "PERatio(TTM)": pe_ratio_ttm,
        "Beta(5Y Monthly)": beta,
        "EPS(TTM)": eps_ttm,
        "EarningsDate": earning_date,
        "ForwardDividend&Yield": f"{forward_dividend} ({forward_dividend_yield})",
        "Ex-DividendDate": exDividend_date,
        "1yTargetEst": target_est
    }

    # Convert the dictionary to a JSON object
    json_data = json.dumps(data_dict, indent=4)

    return json_data

def get_stock_financials(stock_symbol):
    """CurrentPrice, TargetHighPrice, TargetLowPrice, TargetMeanPrice, TargetMedianPrice, RecommendationMean, RecommendationKey, NumberofAnalystOpinions, TotalCash, TotalCashPerShare, EBITDA, TotalDebt, QuickRatio, CurrentRatio, TotalRevenue, DebttoEquity, RevenuePerShare, ReturnonAssets, ReturnonEquity, FreeCashflow, OperatingCashflow, EarningsGrowth, RevenueGrowth, GrossMargins, EBITDAMargins, OperatingMargins, Profit Margins         
    """

    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=financialData"

    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    financial_data = data['quoteSummary']['result'][0]['financialData']

    # Extracting information with fallback to None if key is missing
    current_price = financial_data.get('currentPrice', {}).get('fmt', None)
    target_high_price = financial_data.get('targetHighPrice', {}).get('fmt', None)
    target_low_price = financial_data.get('targetLowPrice', {}).get('fmt', None)
    target_mean_price = financial_data.get('targetMeanPrice', {}).get('fmt', None)
    target_median_price = financial_data.get('targetMedianPrice', {}).get('fmt', None)
    recommendation_mean = financial_data.get('recommendationMean', {}).get('fmt', None)
    recommendation_key = financial_data.get('recommendationKey', None)
    number_of_analyst_opinions = financial_data.get('numberOfAnalystOpinions', {}).get('longFmt', None)
    total_cash = financial_data.get('totalCash', {}).get('longFmt', None)
    total_cash_per_share = financial_data.get('totalCashPerShare', {}).get('fmt', None)
    ebitda = financial_data.get('ebitda', {}).get('longFmt', None)
    total_debt = financial_data.get('totalDebt', {}).get('longFmt', None)
    quick_ratio = financial_data.get('quickRatio', {}).get('fmt', None)
    current_ratio = financial_data.get('currentRatio', {}).get('fmt', None)
    total_revenue = financial_data.get('totalRevenue', {}).get('longFmt', None)
    debt_to_equity = financial_data.get('debtToEquity', {}).get('fmt', None)
    revenue_per_share = financial_data.get('revenuePerShare', {}).get('fmt', None)
    return_on_assets = financial_data.get('returnOnAssets', {}).get('fmt', None)
    return_on_equity = financial_data.get('returnOnEquity', {}).get('fmt', None)
    free_cashflow = financial_data.get('freeCashflow', {}).get('longFmt', None)
    operating_cashflow = financial_data.get('operatingCashflow', {}).get('longFmt', None)
    earnings_growth = financial_data.get('earningsGrowth', {}).get('fmt', None)
    revenue_growth = financial_data.get('revenueGrowth', {}).get('fmt', None)
    gross_margins = financial_data.get('grossMargins', {}).get('fmt', None)
    ebitda_margins = financial_data.get('ebitdaMargins', {}).get('fmt', None)
    operating_margins = financial_data.get('operatingMargins', {}).get('fmt', None)
    profit_margins = financial_data.get('profitMargins', {}).get('fmt', None)

    # Extracted information
    data = {
        "CurrentPrice": current_price,
        "TargetHighPrice": target_high_price,
        "TargetLowPrice": target_low_price,
        "TargetMeanPrice": target_mean_price,
        "TargetMedianPrice": target_median_price,
        "RecommendationMean": recommendation_mean,
        "RecommendationKey": recommendation_key,
        "NumberofAnalystOpinions": number_of_analyst_opinions,
        "TotalCash": total_cash,
        "TotalCashPerShare": total_cash_per_share,
        "EBITDA": ebitda,
        "TotalDebt": total_debt,
        "QuickRatio": quick_ratio,
        "CurrentRatio": current_ratio,
        "TotalRevenue": total_revenue,
        "DebttoEquity": debt_to_equity,
        "RevenuePerShare": revenue_per_share,
        "ReturnonAssets": return_on_assets,
        "ReturnonEquity": return_on_equity,
        "FreeCashflow": free_cashflow,
        "OperatingCashflow": operating_cashflow,
        "EarningsGrowth": earnings_growth,
        "RevenueGrowth": revenue_growth,
        "GrossMargins": gross_margins,
        "EBITDAMargins": ebitda_margins,
        "OperatingMargins": operating_margins,
        "Profit Margins": profit_margins
    }

    # Convert to JSON string
    json_data = json.dumps(data, indent=4)

    # Return the JSON string
    return json_data

def get_stock_recommendation(stock_symbol):
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=financialData"

    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    financial_data = data['quoteSummary']['result'][0]['financialData']

    # Extracting information with fallback to None if key is missing
    current_price = financial_data.get('currentPrice', {}).get('fmt', None)
    target_high_price = financial_data.get('targetHighPrice', {}).get('fmt', None)
    target_low_price = financial_data.get('targetLowPrice', {}).get('fmt', None)
    target_mean_price = financial_data.get('targetMeanPrice', {}).get('fmt', None)
    target_median_price = financial_data.get('targetMedianPrice', {}).get('fmt', None)
    recommendation_mean = financial_data.get('recommendationMean', {}).get('fmt', None)
    recommendation_key = financial_data.get('recommendationKey', None)
    number_of_analyst_opinions = financial_data.get('numberOfAnalystOpinions', {}).get('longFmt', None)
    total_cash = financial_data.get('totalCash', {}).get('longFmt', None)
    total_cash_per_share = financial_data.get('totalCashPerShare', {}).get('fmt', None)
    ebitda = financial_data.get('ebitda', {}).get('longFmt', None)
    total_debt = financial_data.get('totalDebt', {}).get('longFmt', None)
    quick_ratio = financial_data.get('quickRatio', {}).get('fmt', None)
    current_ratio = financial_data.get('currentRatio', {}).get('fmt', None)
    total_revenue = financial_data.get('totalRevenue', {}).get('longFmt', None)
    debt_to_equity = financial_data.get('debtToEquity', {}).get('fmt', None)
    revenue_per_share = financial_data.get('revenuePerShare', {}).get('fmt', None)
    return_on_assets = financial_data.get('returnOnAssets', {}).get('fmt', None)
    return_on_equity = financial_data.get('returnOnEquity', {}).get('fmt', None)
    free_cashflow = financial_data.get('freeCashflow', {}).get('longFmt', None)
    operating_cashflow = financial_data.get('operatingCashflow', {}).get('longFmt', None)
    earnings_growth = financial_data.get('earningsGrowth', {}).get('fmt', None)
    revenue_growth = financial_data.get('revenueGrowth', {}).get('fmt', None)
    gross_margins = financial_data.get('grossMargins', {}).get('fmt', None)
    ebitda_margins = financial_data.get('ebitdaMargins', {}).get('fmt', None)
    operating_margins = financial_data.get('operatingMargins', {}).get('fmt', None)
    profit_margins = financial_data.get('profitMargins', {}).get('fmt', None)

    # Extracted information
    data = {
        "CurrentPrice": current_price,
        "TargetHighPrice": target_high_price,
        "TargetLowPrice": target_low_price,
        "TargetMeanPrice": target_mean_price,
        "TargetMedianPrice": target_median_price,
        "RecommendationMean": recommendation_mean,
        "RecommendationKey": recommendation_key,
        "NumberofAnalystOpinions": number_of_analyst_opinions,
        "TotalCash": total_cash,
        "TotalCashPerShare": total_cash_per_share,
        "EBITDA": ebitda,
        "TotalDebt": total_debt,
        "QuickRatio": quick_ratio,
        "CurrentRatio": current_ratio,
        "TotalRevenue": total_revenue,
        "DebttoEquity": debt_to_equity,
        "RevenuePerShare": revenue_per_share,
        "ReturnonAssets": return_on_assets,
        "ReturnonEquity": return_on_equity,
        "FreeCashflow": free_cashflow,
        "OperatingCashflow": operating_cashflow,
        "EarningsGrowth": earnings_growth,
        "RevenueGrowth": revenue_growth,
        "GrossMargins": gross_margins,
        "EBITDAMargins": ebitda_margins,
        "OperatingMargins": operating_margins,
        "Profit Margins": profit_margins
    }

    # Convert to JSON string
    json_data = json.dumps(data, indent=4)

    # Return the JSON string
    return json_data

def get_stock_Income_Statement(symbol):
    """
    this is the income statement for the last 4 quarters
    like end_date, total_revenue, cost_of_revenue, gross_profit, sga_expenses, total_operating_expenses, operating_income, net_income
    """
    
    url= f"https://yfapi.net/v11/finance/quoteSummary/{symbol}?modules=incomeStatementHistoryQuarterly"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }
    response = requests.request("GET", url, headers=headers)

    data1 = response.json()
    
    end_dateF = []
    total_revenueF = []
    cost_of_revenueF = []
    gross_profitF = []   
    sga_expensesF = []
    total_operating_expensesF = [] 
    operating_incomeF = [] 
    net_incomeF = [] 
    
    for i in range(4):
        # Accessing the necessary information from the data
        data = data1["quoteSummary"]["result"][0]["incomeStatementHistoryQuarterly"]["incomeStatementHistory"][i]
        end_date = data["endDate"].get("fmt", None)
        total_revenue = data["totalRevenue"].get("fmt", None)
        cost_of_revenue = data["costOfRevenue"].get("fmt", None)
        gross_profit = data["grossProfit"].get("fmt", None)
        sga_expenses = data["sellingGeneralAdministrative"].get("fmt", None)
        total_operating_expenses = data["totalOperatingExpenses"].get("fmt", None)
        operating_income = data["operatingIncome"].get("fmt", None)
        net_income = data["netIncome"].get("fmt", None)
        end_dateF.append(end_date) 
        total_revenueF.append(total_revenue) 
        cost_of_revenueF.append(cost_of_revenue) 
        gross_profitF.append(gross_profit) 
        sga_expensesF.append(sga_expenses) 
        total_operating_expensesF.append(total_operating_expenses) 
        operating_incomeF.append(operating_income) 
        net_incomeF.append(net_income)
        
    extracted_data = {
        "end_date": end_dateF,
        "total_revenue": total_revenueF,
        "cost_of_revenue": cost_of_revenueF,
        "gross_profit": gross_profitF,
        "sga_expenses": sga_expensesF,
        "total_operating_expenses": total_operating_expensesF,
        "operating_income": operating_incomeF,
        "net_income": net_incomeF
    }
    
    financial_data_json = json.dumps(extracted_data, indent=4)

    # Printing the JSON data
    # print(financial_data_json)

    return financial_data_json
 
def get_stock_Balance_Sheet(symbol):
    
    url1= f"https://yfapi.net/v11/finance/quoteSummary/{symbol}?modules=balanceSheetHistoryQuarterly "
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response1 = requests.request("GET", url1, headers=headers)
    data = response1.json()

    # Extracting the latest balance sheet statement
    latest_statement = data['quoteSummary']['result'][0]['balanceSheetHistoryQuarterly']['balanceSheetStatements'][1]

    # Extracting specific values from the latest statement
    endDate = latest_statement['endDate'].get('fmt', 'N/A')
    totalStockholderEquity = latest_statement['totalStockholderEquity'].get('fmt', 'N/A')
    netTangibleAssets = latest_statement['netTangibleAssets'].get('fmt', 'N/A')
    # Extracting specific values from the latest statement with error handling
    cash = latest_statement.get('cash', {}).get('fmt', 'N/A')
    shortTermInvestments = latest_statement.get('shortTermInvestments', {}).get('fmt', 'N/A')
    netReceivables = latest_statement.get('netReceivables', {}).get('fmt', 'N/A')
    inventory = latest_statement.get('inventory', {}).get('fmt', 'N/A')
    otherCurrentAssets = latest_statement.get('otherCurrentAssets', {}).get('fmt', 'N/A')
    totalCurrentAssets = latest_statement.get('totalCurrentAssets', {}).get('fmt', 'N/A')
    longTermInvestments = latest_statement.get('longTermInvestments', {}).get('fmt', 'N/A')
    propertyPlantEquipment = latest_statement.get('propertyPlantEquipment', {}).get('fmt', 'N/A')
    goodWill = latest_statement.get('goodWill', {}).get('fmt', 'N/A')
    intangibleAssets = latest_statement.get('intangibleAssets', {}).get('fmt', 'N/A')
    otherAssets = latest_statement.get('otherAssets', {}).get('fmt', 'N/A')
    deferredLongTermAssetCharges = latest_statement.get('deferredLongTermAssetCharges', {}).get('fmt', 'N/A')
    totalAssets = latest_statement.get('totalAssets', {}).get('fmt', 'N/A')
    accountsPayable = latest_statement.get('accountsPayable', {}).get('fmt', 'N/A')
    shortLongTermDebt = latest_statement.get('shortLongTermDebt', {}).get('fmt', 'N/A')
    otherCurrentLiab = latest_statement.get('otherCurrentLiab', {}).get('fmt', 'N/A')
    longTermDebt = latest_statement.get('longTermDebt', {}).get('fmt', 'N/A')
    otherLiab = latest_statement.get('otherLiab', {}).get('fmt', 'N/A')
    deferredLongTermLiab = latest_statement.get('deferredLongTermLiab', {}).get('fmt', 'N/A')
    totalCurrentLiabilities = latest_statement.get('totalCurrentLiabilities', {}).get('fmt', 'N/A')
    totalLiab = latest_statement.get('totalLiab', {}).get('fmt', 'N/A')
    commonStock = latest_statement.get('commonStock', {}).get('fmt', 'N/A')
    retainedEarnings = latest_statement.get('retainedEarnings', {}).get('fmt', 'N/A')
    treasuryStock = latest_statement.get('treasuryStock', {}).get('fmt', 'N/A')
    capitalSurplus = latest_statement.get('capitalSurplus', {}).get('fmt', 'N/A')
    otherStockholderEquity = latest_statement.get('otherStockholderEquity', {}).get('fmt', 'N/A')

    # Creating a dictionary to store the extracted information
    financial_data = {
        'End Date': endDate,
        'Total Stockholder Equity': totalStockholderEquity,
        'Net Tangible Assets': netTangibleAssets,
        'Cash': cash,
        'Short Term Investments': shortTermInvestments,
        'Net Receivables': netReceivables,
        'Inventory': inventory,
        'Other Current Assets': otherCurrentAssets,
        'Total Current Assets': totalCurrentAssets,
        'Long Term Investments': longTermInvestments,
        'Property Plant Equipment': propertyPlantEquipment,
        'Goodwill': goodWill,
        'Intangible Assets': intangibleAssets,
        'Other Assets': otherAssets,
        'Deferred Long Term Asset Charges': deferredLongTermAssetCharges,
        'Total Assets': totalAssets,
        'Accounts Payable': accountsPayable,
        'Short/Long Term Debt': shortLongTermDebt,
        'Other Current Liabilities': otherCurrentLiab,
        'Long Term Debt': longTermDebt,
        'Other Liabilities': otherLiab,
        'Deferred Long Term Liabilities': deferredLongTermLiab,
        'Total Current Liabilities': totalCurrentLiabilities,
        'Total Liabilities': totalLiab,
        'Common Stock': commonStock,
        'Retained Earnings': retainedEarnings,
        'Treasury Stock': treasuryStock,
        'Capital Surplus': capitalSurplus,
        'Other Stockholder Equity': otherStockholderEquity
    }

    # Converting the dictionary to JSON format
    financial_data_json = json.dumps(financial_data, indent=4)


    return financial_data_json

def get_compny_majorHoldersBreakdown(stock_symbol):
    """
    Get the major holders breakdown like:
    - insidersPercentHeld, institutionsPercentHeld, institutionsFloatPercentHeld, institutionsCount
    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=majorHoldersBreakdown"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    results = data["quoteSummary"]["result"][0]["majorHoldersBreakdown"]

    # Extract useful information with fallback to 'N/A' if key is missing
    insiders_percent_held = results.get('insidersPercentHeld', {}).get('fmt', 'N/A')
    institutions_percent_held = results.get('institutionsPercentHeld', {}).get('fmt', 'N/A')
    institutions_float_percent_held = results.get('institutionsFloatPercentHeld', {}).get('fmt', 'N/A')
    institutions_count = results.get('institutionsCount', {}).get('fmt', 'N/A')

    # Create a dictionary with the extracted data
    data_dict = {
        "insidersPercentHeld": insiders_percent_held,
        "institutionsPercentHeld": institutions_percent_held,
        "institutionsFloatPercentHeld": institutions_float_percent_held,
        "institutionsCount": institutions_count
    }

    # Convert the dictionary to a JSON object
    json_data = json.dumps(data_dict, indent=4)

    return json_data
 
def get_stock_esg_score(symbol):
    """
    measure of a company's performance in environmental, social, and governance areas, with higher scores indicating better performance
    """
    url= f"https://yfapi.net/v11/finance/quoteSummary/{symbol}?modules=esgScores"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()
  
    # Extract useful information
    

    # result = data["quoteSummary"]["result"][0]["esgScores"]
    
    # for key in result:
    #     print(key, result[key])


    # json_data = json.dumps(data, indent=4)

    # Print the JSON string
    # print(json_data)
    print(data)
    return data

def get_stock_earnings_histroy(symbol):
    """
    get_stock_earnings_history() function extracts the earnings history of a stock from Yahoo Finance.
    like:
    EPS EST , EPS Actual , Difference , Surprise % 

    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{symbol}?modules=earningsHistory"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)

    data = response.json()

    # Extract earnings history
    earnings_history = data['quoteSummary']['result'][0]['earningsHistory']['history']

    # Initialize lists for each metric
    dates = []
    eps_estimates = []
    eps_actuals = []
    differences = []
    surprise_percentages = []

    # Iterate over each quarter and extract the relevant information
    for quarter in earnings_history:
        date = quarter['quarter'].get('fmt', 'N/A')

        # Handle missing data for EPS Est., EPS Actual, Difference, and Surprise %
        estimate = quarter.get('epsEstimate', {}).get('raw', 'N/A')
        actual = quarter.get('epsActual', {}).get('raw', 'N/A')
        difference = quarter.get('epsDifference', {}).get('raw', 'N/A')
        surprise_percentage = quarter.get('surprisePercent', {}).get('fmt', 'N/A')

        # Append the values to the corresponding lists
        dates.append(date)
        eps_estimates.append(estimate)
        eps_actuals.append(actual)
        differences.append(difference)
        surprise_percentages.append(surprise_percentage)

    extracted_data = {
        "Earnings History": dates,
        "EPS Est.": eps_estimates,
        "EPS Actual": eps_actuals,
        "Difference": differences,
        "Surprise %": surprise_percentages
    }

    # Convert the dictionary to JSON
    json_data = json.dumps(extracted_data, indent=4)

    # Print the JSON data
    # print(json_data)

    return json_data

def get_stock_indexTrend(symbol):
    """
    get the stock indexTrend
    like: symbol, peg_ratio, periods, growth_rates
    """
    url= f"https://yfapi.net/v11/finance/quoteSummary/{symbol}?modules=indexTrend"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    json_data = response.json()

    # Extract the required information
    result = json_data['quoteSummary']['result'][0]['indexTrend']
    symbol = result['symbol']
    pe_ratio = result.get('peRatio', {}).get('raw', 'N/A')
    peg_ratio = result.get('pegRatio', {}).get('raw', 'N/A')
    estimates = result.get('estimates', [])

    periods = []
    growth_rates = []

    for estimate in estimates:
        period = estimate.get('period', 'N/A')
        growth = estimate.get('growth', {}).get('raw', 'N/A')
        periods.append(period)
        growth_rates.append(growth)

    data = {
        "symbol": symbol,
        "pe_ratio": pe_ratio,
        "peg_ratio": peg_ratio,
        "periods": periods,
        "growth_rates": growth_rates
    }
    json_data = json.dumps(data, indent=4)

    # Print the JSON data
    # print(json_data)

    return json_data

def get_stock_sentiments(stock_symbol):
    """
    Get the latest news for a stock
    """
  
    url = "https://yfinance-stock-market-data.p.rapidapi.com/news"

    payload = { "symbol": stock_symbol }
    headers = {
        "content-type": "application/x-www-form-urlencoded",
        "X-RapidAPI-Key": "86a7de1381msh0ffc95b4860438fp14b810jsnce8e3ed4a655",
        "X-RapidAPI-Host": "yfinance-stock-market-data.p.rapidapi.com"
    }

    response = requests.post(url, data=payload, headers=headers)
    data = []
    for i in response.json()['data']:
        data.append(i['title'])
    return data
    
def get_stock_calendarEvents(stock_symbol):
    """
    get stock calendarEvents - like earnings dates, earnings average, earnings low, earnings high, revenue average, revenue low, revenue high
    """
    url = f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=calendarEvents"
    headers = {
        'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
    }

    response = requests.request("GET", url, headers=headers)
    data = response.json()

    # Extracting earnings data
    earnings_data = data["quoteSummary"]["result"][0]["calendarEvents"]["earnings"]
    earnings_dates = [item["fmt"] for item in earnings_data["earningsDate"]]
    earnings_average = earnings_data.get("earningsAverage", {}).get("fmt", "N/A")
    earnings_low = earnings_data.get("earningsLow", {}).get("fmt", "N/A")
    earnings_high = earnings_data.get("earningsHigh", {}).get("fmt", "N/A")

    # Extracting revenue data
    revenue_average = earnings_data.get("revenueAverage", {}).get("longFmt", "N/A")
    revenue_low = earnings_data.get("revenueLow", {}).get("longFmt", "N/A")
    revenue_high = earnings_data.get("revenueHigh", {}).get("longFmt", "N/A")

    # Prepare the data to be dumped into JSON format
    output_data = {
        "Earnings Dates": earnings_dates,
        "Earnings Average": earnings_average,
        "Earnings Low": earnings_low,
        "Earnings High": earnings_high,
        "Revenue Average": revenue_average,
        "Revenue Low": revenue_low,
        "Revenue High": revenue_high,
        "currency": "INR"
    }

    # Dump the data into JSON format
    json_data = json.dumps(output_data, indent=2)

    return json_data

def get_stock_earningsTrend(stock_symbol):
	"""
	get stock earningsTrend - like growth rates, earnings estimates, revenue estimates
 	"""
	url= f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=earningsTrend"
	headers = {
		'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
	}

	response = requests.request("GET", url, headers=headers)

	data = response.json()

	# Extracting earnings trend data
	earnings_trend = data["quoteSummary"]["result"][0]["earningsTrend"]["trend"]

	# Extracting growth rates for each period
	growth_rates = [{"period": item["period"], "growth": item["growth"]["fmt"]} for item in earnings_trend]

	# Extracting earnings estimates for each period
	earnings_estimates = []
	for item in earnings_trend:
		earnings_estimate = {
			"period": item["period"],
			"average": item["earningsEstimate"]["avg"].get("fmt", None),  # Using get() to handle missing 'fmt' key
			"low": item["earningsEstimate"]["low"].get("fmt", None),      # Using get() to handle missing 'fmt' key
			"high": item["earningsEstimate"]["high"].get("fmt", None)     # Using get() to handle missing 'fmt' key
		}
		earnings_estimates.append(earnings_estimate)

	# Extracting revenue estimates for each period
	revenue_estimates = []
	for item in earnings_trend:
		revenue_estimate = {
			"period": item["period"],
			"average": item["revenueEstimate"]["avg"].get("longFmt", None),  # Using get() to handle missing 'longFmt' key
			"low": item["revenueEstimate"]["low"].get("longFmt", None),      # Using get() to handle missing 'longFmt' key
			"high": item["revenueEstimate"]["high"].get("longFmt", None)     # Using get() to handle missing 'longFmt' key
		}
		revenue_estimates.append(revenue_estimate)

	# Prepare the data to be dumped into JSON format
	output_data = {
		"Growth Rates": growth_rates,
		"Earnings Estimates": earnings_estimates,
		"Revenue Estimates": revenue_estimates,
        "currency": "INR"
	}

	# Dump the data into JSON format
	json_output = json.dumps(output_data, indent=2)
 
	return json_output

if __name__ == '__main__':

    # get_stock_statistics("wipro")
    # print(get_stock_news("wipro"))
    # print(get_stock_sentiments("wipro"))
    
    print(get_stock_recommendation("IDEA.NS"))
    # print(get_stock_Balance_Sheet("WIPRO.NS"))
    
    
    # # get stock price
    # stock_symbol = "WIPRO"  # Replace with the desired stock symbol
    # price = get_stock_price(stock_symbol)
    # if price is not None:
    #     print(f"The current price of {stock_symbol} is ₹{price:.2f}")
    # else:
    #     print(f"Failed to retrieve the price for {stock_symbol}")
    
    # print(get_stock_financials("wipro.ns"))
    # print(get_stock_summary("wipro.ns"))
    
    
    
    
    
    
# def get_stock_news(stock_symbol):
#     """
#     Get the latest news for a stock
#     """
  
#     url = "https://yfinance-stock-market-data.p.rapidapi.com/news"

#     payload = { "symbol": stock_symbol }
#     headers = {
#         "content-type": "application/x-www-form-urlencoded",
#         "X-RapidAPI-Key": "86a7de1381msh0ffc95b4860438fp14b810jsnce8e3ed4a655",
#         "X-RapidAPI-Host": "yfinance-stock-market-data.p.rapidapi.com"
#     }

#     response = requests.post(url, data=payload, headers=headers)
#     data = {}
#     for i in response.json()['data']:
#         data[i['title']] = i['link']
     
#     # print(response.json())
        
#     return data