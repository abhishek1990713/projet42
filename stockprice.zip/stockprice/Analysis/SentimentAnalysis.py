import spacy
from spacytextblob.spacytextblob import SpacyTextBlob

# Load the spaCy English model
nlp = spacy.load('en_core_web_md')

# Add the spaCyTextBlob component to the pipeline
nlp.add_pipe('spacytextblob')

# Define a function for sentiment analysis
def analyze_sentiment(text):
    doc = nlp(text)
    polarity = doc._.polarity
    subjectivity = doc._.subjectivity

    if polarity > 0.5:
        sentiment = "Very positive"
    elif polarity > 0:
        sentiment = "Positive"
    elif polarity == 0:
        sentiment = "Neutral"
    elif polarity > -0.5:
        sentiment = "Negative"
    else:
        sentiment = "Very negative"

    # Additional features
    word_count = len(doc)
    sentence_count = len(list(doc.sents))

    # Return the sentiment and additional features
    return sentiment, polarity, subjectivity

if __name__ == '__main__':
    # text = "I love this movie! It's fantastic."
    text = """'Indian IT Giant Spending $1 Billion to Train Entire Staff in AI', 'Wipro Launches Wipro ai360, Commits to Investing $1 Billion in AI Over the Next Three Years', "India's Wipro commits $1 billion investment into AI", '10 Most Undervalued Cybersecurity Stocks To Buy According To Hedge Funds', 'Wipro Limited to Announce Results for the First Quarter Ended June 30, 2023, on July 13, 2023', 'Wipro Expands Presence in South Africa, Inaugurates New Office in Cape Town', 'Wipro Opens New 5G Def-i Innovation Center in Austin, Texas', 'Wipro and Cisco Launch Managed Private 5G-as-a-Service Solution to Accelerate Enterprise Digital Transformation'"""
    # text = "Watch: PM Modi, toasting with ginger ale at State Dinner, laughs at Joe Biden's alcohol joke"
    # ['Indian IT Giant Spending $1 Billion to Train Entire Staff in AI', 'Wipro Launches Wipro ai360, Commits to Investing $1 Billion in AI Over the Next Three Years', "India's Wipro commits $1 billion investment into AI", '10 Most Undervalued Cybersecurity Stocks To Buy According To Hedge Funds', 'Wipro Limited to Announce Results for the First Quarter Ended June 30, 2023, on July 13, 2023', 'Wipro Expands Presence in South Africa, Inaugurates New Office in Cape Town', 'Wipro Opens New 5G Def-i Innovation Center in Austin, Texas', 'Wipro and Cisco Launch Managed Private 5G-as-a-Service Solution to Accelerate Enterprise Digital Transformation']
    sentiment, polarity, subjectivity = analyze_sentiment(text)

    print("Text:", text)
    print("Sentiment:", sentiment)
    print("Polarity:", polarity)
    print("Subjectivity:", subjectivity)
 
