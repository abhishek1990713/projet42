// Collapsible

// localStorage.clear();

var local_conversation = localStorage.getItem('conversation');
if (local_conversation == null){
    var conversation = [];
}
else{

    var conversation = JSON.parse(local_conversation);
    console.log(conversation);


    for (items in conversation){
        item = conversation[items]        
        if (item.who == "user"){

            let userHtml = '<p class="userText"><span>' + item.text + '</span></p>';
            $("#textInput").val("");
            $("#chatbox").append(userHtml);
                              
        }
        else{
            let botHtml = '<p class="botText"><span>' + item.text + '</span></p>';
            $("#chatbox").append(botHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);
        }
    }
    document.getElementById("chat-bar-bottom").scrollIntoView(true);
}


var coll = document.getElementsByClassName("collapsible");

var svg_element = document.getElementsByTagName('svg');


for (let i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
 
        var content = this.nextElementSibling;

        if (content.style.maxHeight) {            
            document.getElementById('svg_ui').innerHTML = '<svg id="svg_ui" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="comment-dots" class="svg-inline--fa fa-comment-dots fa-w-16 css-1fcbxrh" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="width: 1.3em;"><path id="msg" fill="white" d="M256 32C114.6 32 0 125.1 0 240c0 49.6 21.4 95 57 130.7C44.5 421.1 2.7 466 2.2 466.5c-2.2 2.3-2.8 5.7-1.5 8.7S4.8 480 8 480c66.3 0 116-31.8 140.6-51.4 32.7 12.3 69 19.4 107.4 19.4 141.4 0 256-93.1 256-208S397.4 32 256 32zM128 272c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32zm128 0c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32zm128 0c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32z"></path></svg>';
            content.style.maxHeight = null;
            document.getElementById('chat-button').style.padding = "21px 22px 15px 22px";
            document.getElementById('chat-bar').style.boxShadow = "0px 0px 0px white";
        } else {
            document.getElementById('without-collapsible').style.boxShadow = "rgba(0, 0, 0, 0.25) 0px 14px 28px, rgba(0, 0, 0, 0.22) 0px 10px 10px";
            document.getElementById('chat-button').style.padding = "20px 25px 11px 25px";
            document.getElementById('svg_ui').innerHTML = '<svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="times" class="svg-inline--fa fa-times fa-w-10 css-1fcbxrh" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width: 1em;"><path fill="currentColor" d="M193.94 256L296.5 153.44l21.15-21.15c3.12-3.12 3.12-8.19 0-11.31l-22.63-22.63c-3.12-3.12-8.19-3.12-11.31 0L160 222.06 36.29 98.34c-3.12-3.12-8.19-3.12-11.31 0L2.34 120.97c-3.12 3.12-3.12 8.19 0 11.31L126.06 256 2.34 379.71c-3.12 3.12-3.12 8.19 0 11.31l22.63 22.63c3.12 3.12 8.19 3.12 11.31 0L160 289.94 262.56 392.5l21.15 21.15c3.12 3.12 8.19 3.12 11.31 0l22.63-22.63c3.12-3.12 3.12-8.19 0-11.31L193.94 256z"></path></svg>';
            content.style.maxHeight = content.scrollHeight + "px";            
        }

    });
}

function getTime() {
    let today = new Date();
    hours = today.getHours();
    minutes = today.getMinutes();

    if (hours < 10) {
        hours = "0" + hours;
    }

    if (minutes < 10) {
        minutes = "0" + minutes;
    }

    let time = hours + ":" + minutes;
    return time;
}

// Gets the first message
function firstBotMessage() {
    let firstMessage = "How can I help you? for Stock Market related queries."
    document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';

    let time = getTime();

    $("#chat-timestamp").append(time);
    document.getElementById("userInput").scrollIntoView(false);
}

firstBotMessage();

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Retrieves the response
async function getHardResponse(userText) {
    document.getElementsByClassName("dot-1")[0].style.display = "inline-block";
    document.getElementsByClassName("dot-2")[0].style.display = "inline-block";
    document.getElementsByClassName("dot-3")[0].style.display = "inline-block";
    
    const csrftoken = getCookie('csrftoken');
    
    const response = await fetch('/ask_question', {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCookie('csrftoken')
        },
        body: JSON.stringify({"question": userText})
    });

    document.getElementsByClassName("dot-1")[0].style.display = "none";
    document.getElementsByClassName("dot-2")[0].style.display = "none";
    document.getElementsByClassName("dot-3")[0].style.display = "none";

    let botResponse = await response.text(); 
    let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
    $("#chatbox").append(botHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    conversation.push({"who": "bot", "text":botResponse});
    
    localStorage.setItem('conversation', JSON.stringify(conversation));

}

//Gets the text text from the input box and processes it
function getResponse() {

    let userText = $("#textInput").val();
    console.log("hi");

    if (userText == "") {
        return 0;
    }

    let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    conversation.push({"who":"user" ,"text":userText});

    setTimeout(() => {
        getHardResponse(userText);
    }, 1000)

}

// Handles sending text via button clicks
// function buttonSendText(sampleText) {
//     let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';
//     $("#textInput").val("");
//     $("#chatbox").append(userHtml);
//     document.getElementById("chat-bar-bottom").scrollIntoView(true);
    
// }

function sendButton() {
    getResponse();
}

function heartButton() {
    buttonSendText("Heart clicked!")
}

// Press enter to send a message
$("#textInput").keypress(function (e) {
    if (e.which == 13) {
        getResponse();
    }
});

