from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import StandardScaler
import numpy as np

def build_model(features, target):
    # Standardize the features using a scaler
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)

    # Extract additional features
    additional_features = np.mean(features_scaled, axis=1)

    # Concatenate the additional features with the original features
    combined_features = np.concatenate((features_scaled, additional_features[:, np.newaxis]), axis=1)

    # Reshape the combined features for LSTM input shape (number of samples, timesteps, number of features)
    combined_features = combined_features.reshape(combined_features.shape[0], combined_features.shape[1], 1)

    # Build the LSTM model
    model = Sequential()
    model.add(LSTM(64, return_sequences=True, input_shape=(combined_features.shape[1], 1)))
    model.add(Dropout(0.2))
    model.add(LSTM(64, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')

    # Fit the model to the training data
    model.fit(combined_features, target, epochs=10, batch_size=32)

    return model

def predict_future_values(model, features, num_days):
    # Standardize the features using the same scaler used during training
    features_scaled = scaler.transform(features)

    # Extract additional features
    additional_features = np.mean(features_scaled, axis=1)

    # Concatenate the additional features with the standardized features
    combined_features = np.concatenate((features_scaled, additional_features[:, np.newaxis]), axis=1)

    # Reshape the combined features for LSTM input shape (number of samples, timesteps, number of features)
    combined_features = combined_features.reshape(combined_features.shape[0], combined_features.shape[1], 1)

    # Predict future values for the given number of days
    future_values = []
    last_features = combined_features[-1]
    for _ in range(num_days):
        prediction = model.predict(last_features.reshape(1, last_features.shape[0], 1))
        future_values.append(prediction[0][0])

        # Update the last features with the predicted value for the next prediction
        last_features = np.concatenate((last_features[1:], [[prediction[0][0]]]), axis=0)

    # Inverse transform the predicted future values
    future_values = scaler.inverse_transform(future_values)

    return future_values
