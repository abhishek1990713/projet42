# from newsapi import NewsApiClient

# # Init
# newsapi = NewsApiClient(api_key='f6e2b246217741269a0fa6542cbf9521')

# print("Top Headlines" + "\n") 

# # /v2/top-headlines
# top_headlines = newsapi.get_everything(q='Balrampur Chini Mills Ltd',language='en')

# # top_headlines = newsapi.get_top_headlines( country='in',category='business' , language='en')

# print(top_headlines)

import requests

def get_stock_price(symbol):
    url = f"https://newsapi.org/v2/everything?q=ITC&apiKey=dd2cd016504c48f89686d3b46dc87e0d&sources=the-times-of-india,google-news-in,the-hindu&language=en"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0;Win64) AppleWebkit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()
        news = data["articles"][0]
        print(news)
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return None

# Example usage
symbol = "RELIANCE"  # Replace with your desired stock symbol
price = get_stock_price(symbol)
if price:
    print(f"Current price of {symbol}: {price}")
