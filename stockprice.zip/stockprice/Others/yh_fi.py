import requests
import json

def get_stock_indexTrend(symbol):
    """
    get the stock indexTrend
    like : symbol, pe_ratio, peg_ratio, periods, growth_rates
    """
    url= f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{symbol}?modules=indexTrend"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }

    response = requests.get(url, headers=headers)
    
    json_data = response.json()
        
    # Extract the required information
    symbol = json_data['quoteSummary']['result'][0]['indexTrend']['symbol']
    pe_ratio = json_data['quoteSummary']['result'][0]['indexTrend']['peRatio']['raw']
    peg_ratio = json_data['quoteSummary']['result'][0]['indexTrend']['pegRatio']['raw']
    estimates = json_data['quoteSummary']['result'][0]['indexTrend']['estimates']
    periods = []
    growth_rates = []

    for estimate in estimates:
        period = estimate['period']
        growth = estimate['growth']['raw'] if 'raw' in estimate['growth'] else "N/A"
        periods.append(period)
        growth_rates.append(growth)

    data = {
        "symbol": symbol,
        "pe_ratio": pe_ratio,
        "peg_ratio": peg_ratio,
        "periods": periods,
        "growth_rates": growth_rates
    }
    json_data = json.dumps(data)

    # Print the JSON data
    print(json_data)

    return json_data

get_stock_indexTrend("WIPRO.NS")



