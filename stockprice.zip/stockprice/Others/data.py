# import requests

# url = "https://twelve-data1.p.rapidapi.com/dividends"

# querystring = {"symbol":"wipro","range":"6m","country":"India"}

# headers = {
# 	"X-RapidAPI-Key": "86a7de1381msh0ffc95b4860438fp14b810jsnce8e3ed4a655",
# 	"X-RapidAPI-Host": "twelve-data1.p.rapidapi.com"
# }

# response = requests.get(url, headers=headers, params=querystring)

# print(response.json())

import requests
import json



def get_stock_earningsTrend(stock_symbol):
	"""
	get stock earningsTrend - like growth rates, earnings estimates, revenue estimates
 	"""
	url= f"https://yfapi.net/v11/finance/quoteSummary/{stock_symbol}?modules=earningsTrend"
	headers = {
		'x-api-key': "wbeN45dxCr95fnjtQRMTGIqfixL7nSSgq7jNaR30"
	}

	response = requests.request("GET", url, headers=headers)

	data = response.json()

	# Extracting earnings trend data
	earnings_trend = data["quoteSummary"]["result"][0]["earningsTrend"]["trend"]

	# Extracting growth rates for each period
	growth_rates = [{"period": item["period"], "growth": item["growth"]["fmt"]} for item in earnings_trend]

	# Extracting earnings estimates for each period
	earnings_estimates = []
	for item in earnings_trend:
		earnings_estimate = {
			"period": item["period"],
			"average": item["earningsEstimate"]["avg"].get("fmt", None),  # Using get() to handle missing 'fmt' key
			"low": item["earningsEstimate"]["low"].get("fmt", None),      # Using get() to handle missing 'fmt' key
			"high": item["earningsEstimate"]["high"].get("fmt", None)     # Using get() to handle missing 'fmt' key
		}
		earnings_estimates.append(earnings_estimate)

	# Extracting revenue estimates for each period
	revenue_estimates = []
	for item in earnings_trend:
		revenue_estimate = {
			"period": item["period"],
			"average": item["revenueEstimate"]["avg"].get("longFmt", None),  # Using get() to handle missing 'longFmt' key
			"low": item["revenueEstimate"]["low"].get("longFmt", None),      # Using get() to handle missing 'longFmt' key
			"high": item["revenueEstimate"]["high"].get("longFmt", None)     # Using get() to handle missing 'longFmt' key
		}
		revenue_estimates.append(revenue_estimate)

	# Prepare the data to be dumped into JSON format
	output_data = {
		"Growth Rates": growth_rates,
		"Earnings Estimates": earnings_estimates,
		"Revenue Estimates": revenue_estimates
	}

	# Dump the data into JSON format
	json_output = json.dumps(output_data, indent=2)
 
	return json_output

print(get_stock_earningsTrend("WIPRO.NS"))
