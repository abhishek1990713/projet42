import requests

def get_company_fundamentals(ticker):
    url = f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{ticker}?modules=financialData"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        fundamentals = data["quoteSummary"]["result"][0]["financialData"]
        return fundamentals
    else:
        return None

def get_company_Statistics(ticker):
    url = f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{ticker}?modules=defaultKeyStatistics"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        fundamentals = data["quoteSummary"]["result"][0]["defaultKeyStatistics"]
        return fundamentals
    else:
        return None

def analyze_company_fundamentals(fundamentals):
    analysis = {}
    
    # Example analysis criteria - Modify or add more metrics based on your preferences
    # Current price
    if fundamentals.get("currentPrice"):
        analysis["current_price"] = fundamentals["currentPrice"]["raw"]
    
    # Target prices
    if fundamentals.get("targetHighPrice"):
        analysis["target_high_price"] = fundamentals["targetHighPrice"]["raw"]
    if fundamentals.get("targetLowPrice"):
        analysis["target_low_price"] = fundamentals["targetLowPrice"]["raw"]
    if fundamentals.get("targetMeanPrice"):
        analysis["target_mean_price"] = fundamentals["targetMeanPrice"]["raw"]
    if fundamentals.get("targetMedianPrice"):
        analysis["target_median_price"] = fundamentals["targetMedianPrice"]["raw"]
    
    # Recommendation details
    if fundamentals.get("recommendationMean"):
        analysis["recommendation_mean"] = fundamentals["recommendationMean"]["raw"]
    if fundamentals.get("recommendationKey"):
        analysis["recommendation_key"] = fundamentals["recommendationKey"]
    if fundamentals.get("numberOfAnalystOpinions"):
        analysis["number_of_analyst_opinions"] = fundamentals["numberOfAnalystOpinions"]["raw"]
    
    # Total cash and total cash per share
    if fundamentals.get("totalCash"):
        analysis["total_cash"] = fundamentals["totalCash"]["raw"]
    if fundamentals.get("totalCashPerShare"):
        analysis["total_cash_per_share"] = fundamentals["totalCashPerShare"]["raw"]
    
    # EBITDA (Earnings Before Interest, Taxes, Depreciation, and Amortization)
    if fundamentals.get("ebitda"):
        analysis["ebitda"] = fundamentals["ebitda"]["raw"]
    
    # Total debt
    if fundamentals.get("totalDebt"):
        analysis["total_debt"] = fundamentals["totalDebt"]["raw"]
    
    # Liquidity ratios
    if fundamentals.get("quickRatio"):
        analysis["quick_ratio"] = fundamentals["quickRatio"]["raw"]
    if fundamentals.get("currentRatio"):
        analysis["current_ratio"] = fundamentals["currentRatio"]["raw"]
    
    # Total revenue
    if fundamentals.get("totalRevenue"):
        analysis["total_revenue"] = fundamentals["totalRevenue"]["raw"]
    
    # Debt to equity ratio
    if fundamentals.get("debtToEquity"):
        analysis["debt_to_equity"] = fundamentals["debtToEquity"]["raw"]
    
    # Revenue per share
    if fundamentals.get("revenuePerShare"):
        analysis["revenue_per_share"] = fundamentals["revenuePerShare"]["raw"]
    
    # Return on assets and return on equity
    if fundamentals.get("returnOnAssets"):
        analysis["return_on_assets"] = fundamentals["returnOnAssets"]["raw"]
    if fundamentals.get("returnOnEquity"):
        analysis["return_on_equity"] = fundamentals["returnOnEquity"]["raw"]
    
    # Gross profits
    if fundamentals.get("grossProfits"):
        analysis["gross_profits"] = fundamentals["grossProfits"]["raw"]
    
    # Free cash flow and operating cash flow
    if fundamentals.get("freeCashflow"):
        analysis["free_cash_flow"] = fundamentals["freeCashflow"]["raw"]
    if fundamentals.get("operatingCashflow"):
        analysis["operating_cash_flow"] = fundamentals["operatingCashflow"]["raw"]
    
    # Earnings growth and revenue growth
    if fundamentals.get("earningsGrowth"):
        analysis["earnings_growth"] = fundamentals["earningsGrowth"]["raw"]
    if fundamentals.get("revenueGrowth"):
        analysis["revenue_growth"] = fundamentals["revenueGrowth"]["raw"]
    
    # Gross margins, EBITDA margins, operating margins, and profit margins
    if fundamentals.get("grossMargins"):
        analysis["gross_margins"] = fundamentals["grossMargins"]["raw"]
    if fundamentals.get("ebitdaMargins"):
        analysis["ebitda_margins"] = fundamentals["ebitdaMargins"]["raw"]
    if fundamentals.get("operatingMargins"):
        analysis["operating_margins"] = fundamentals["operatingMargins"]["raw"]
    if fundamentals.get("profitMargins"):
        analysis["profit_margins"] = fundamentals["profitMargins"]["raw"]
    
    # Financial currency
    if fundamentals.get("financialCurrency"):
        analysis["financial_currency"] = fundamentals["financialCurrency"]
    
    # Add more analysis criteria here based on available fundamental metrics
    
    return analysis

print(analyze_company_fundamentals(get_company_fundamentals("WIPRO.NS")))

def recommend_stocks(tickers):
    recommended_stocks = []
    for ticker in tickers:
        fundamentals = get_company_fundamentals(ticker)
        if fundamentals is not None:
            analysis = analyze_company_fundamentals(fundamentals)
            
            # Example recommendation logic - Modify or add more criteria as desired
            
            # Check for positive revenue growth and strong profit margins
            if "revenue_growth" in analysis and analysis["revenue_growth"] > 0 and \
                "profit_margins" in analysis and analysis["profit_margins"] > 0.1:
                recommended_stocks.append(ticker)
            
            # Check for low debt-to-equity ratio and high return on equity
            if "debt_to_equity" in analysis and analysis["debt_to_equity"] < 1 and \
                "return_on_equity" in analysis and analysis["return_on_equity"] > 0.15:
                recommended_stocks.append(ticker)
            
            # Check for positive recommendation and a sufficient number of analyst opinions
            if "recommendation_mean" in analysis and analysis["recommendation_mean"] <= 2.0 and \
                "number_of_analyst_opinions" in analysis and analysis["number_of_analyst_opinions"] >= 3:
                recommended_stocks.append(ticker)
            
            # Check for current price below the target mean price
            if "current_price" in analysis and "target_mean_price" in analysis and \
                analysis["current_price"] < analysis["target_mean_price"]:
                recommended_stocks.append(ticker)
            
            # Check for low debt-to-equity ratio and positive free cash flow
            if "debt_to_equity" in analysis and analysis["debt_to_equity"] < 0.5 and \
                "free_cash_flow" in analysis and analysis["free_cash_flow"] > 0:
                recommended_stocks.append(ticker)
            
            # Check for high return on assets and high return on equity
            if "return_on_assets" in analysis and analysis["return_on_assets"] > 0.1 and \
                "return_on_equity" in analysis and analysis["return_on_equity"] > 0.2:
                recommended_stocks.append(ticker)
            
            # Check for high revenue growth and high gross margins
            if "revenue_growth" in analysis and analysis["revenue_growth"] > 0.2 and \
                "gross_margins" in analysis and analysis["gross_margins"] > 0.3:
                recommended_stocks.append(ticker)
            
            # Check for positive earnings growth and positive operating margins
            if "earnings_growth" in analysis and analysis["earnings_growth"] > 0 and \
                "operating_margins" in analysis and analysis["operating_margins"] > 0:
                recommended_stocks.append(ticker)
            
            # Check for positive free cash flow and high revenue per share
            if "free_cash_flow" in analysis and analysis["free_cash_flow"] > 0 and \
                "revenue_per_share" in analysis and analysis["revenue_per_share"] > 100:
                recommended_stocks.append(ticker)
            
            # Check for low valuation based on price-to-earnings ratio
            if "current_price" in analysis and "earnings_per_share" in analysis and \
                analysis["current_price"] < analysis["earnings_per_share"] * 15:
                recommended_stocks.append(ticker)
            
            # Check for positive operating margins and improving earnings growth
            if "operating_margins" in analysis and analysis["operating_margins"] > 0 and \
                "earnings_growth" in analysis and analysis["earnings_growth"] > 0.05:
                recommended_stocks.append(ticker)
            
            # Check for high liquidity based on current ratio and quick ratio
            if "current_ratio" in analysis and analysis["current_ratio"] > 1.5 and \
                "quick_ratio" in analysis and analysis["quick_ratio"] > 1:
                recommended_stocks.append(ticker)
            
            # Check for high EBITDA margins and gross margins
            if "ebitda_margins" in analysis and analysis["ebitda_margins"] > 0.1 and \
                "gross_margins" in analysis and analysis["gross_margins"] > 0.2:
                recommended_stocks.append(ticker)
            
            # Check for positive operating cash flow and improving gross margins
            if "operating_cash_flow" in analysis and analysis["operating_cash_flow"] > 0 and \
                "gross_margins" in analysis and analysis["gross_margins"] > 0.1:
                recommended_stocks.append(ticker)
            
            # Check for positive earnings growth and low valuation based on PEG ratio
            if "earnings_growth" in analysis and analysis["earnings_growth"] > 0 and \
                "peg_ratio" in analysis and analysis["peg_ratio"] < 1:
                recommended_stocks.append(ticker)
            
            # Check for positive revenue growth and low price-to-sales ratio
            if "revenue_growth" in analysis and analysis["revenue_growth"] > 0 and \
                "price_to_sales_ratio" in analysis and analysis["price_to_sales_ratio"] < 2:
                recommended_stocks.append(ticker)
            
            # Check for positive operating cash flow and improving gross margins
            if "operating_cash_flow" in analysis and analysis["operating_cash_flow"] > 0 and \
                "gross_margins" in analysis and analysis["gross_margins"] > 0.1:
                recommended_stocks.append(ticker)
            
            # Check for positive net income and high return on equity
            if "net_income" in analysis and analysis["net_income"] > 0 and \
                "return_on_equity" in analysis and analysis["return_on_equity"] > 0.15:
                recommended_stocks.append(ticker)
            
            # Add more recommendation criteria based on the available analysis
            
    return recommended_stocks

# # Example usage
# stock_tickers = ["AAPL", "GOOGL", "MSFT", "AMZN", "FB"]
# recommended_stocks = recommend_stocks(stock_tickers)

# print("Recommended Stocks:")
# if recommended_stocks:
#     for stock in recommended_stocks:
#         print(stock)
# else:
#     print("No stocks meet the recommended criteria.")

def analyze_company_Statistics(fundamentals):
    analysis = {}
    
    # Example analysis criteria - Modify or add more metrics based on your preferences
    
    # Profit margins
    if fundamentals.get("profitMargins"):
        analysis["profit_margins"] = fundamentals["profitMargins"]["raw"]
    
    # Shares outstanding
    if fundamentals.get("sharesOutstanding"):
        analysis["shares_outstanding"] = fundamentals["sharesOutstanding"]["raw"]
    
    # Beta
    if fundamentals.get("beta"):
        analysis["beta"] = fundamentals["beta"]["raw"]
    
    # Book value
    if fundamentals.get("bookValue"):
        analysis["book_value"] = fundamentals["bookValue"]["raw"]
    
    # Price to book ratio
    if fundamentals.get("priceToBook"):
        analysis["price_to_book"] = fundamentals["priceToBook"]["raw"]
    
    # Earnings per share (EPS)
    if fundamentals.get("trailingEps"):
        analysis["earnings_per_share"] = fundamentals["trailingEps"]["raw"]
    
    # Forward EPS
    if fundamentals.get("forwardEps"):
        analysis["forward_eps"] = fundamentals["forwardEps"]["raw"]
    
    # PEG ratio
    if fundamentals.get("pegRatio"):
        analysis["peg_ratio"] = fundamentals["pegRatio"]["raw"]
    
    # Enterprise to revenue ratio
    if fundamentals.get("enterpriseToRevenue"):
        analysis["enterprise_to_revenue"] = fundamentals["enterpriseToRevenue"]["raw"]
    
    # Enterprise to EBITDA ratio
    if fundamentals.get("enterpriseToEbitda"):
        analysis["enterprise_to_ebitda"] = fundamentals["enterpriseToEbitda"]["raw"]
    
    # 52-week change
    if fundamentals.get("52WeekChange"):
        analysis["52_week_change"] = fundamentals["52WeekChange"]["raw"]
    
    # Revenue quarterly growth
    if fundamentals.get("revenueQuarterlyGrowth"):
        analysis["revenue_quarterly_growth"] = fundamentals["revenueQuarterlyGrowth"]["raw"]
    
    # Net income to common
    if fundamentals.get("netIncomeToCommon"):
        analysis["net_income_to_common"] = fundamentals["netIncomeToCommon"]["raw"]
    
    # Earnings quarterly growth
    if fundamentals.get("earningsQuarterlyGrowth"):
        analysis["earnings_quarterly_growth"] = fundamentals["earningsQuarterlyGrowth"]["raw"]
    
    # Last dividend value
    if fundamentals.get("lastDividendValue"):
        analysis["last_dividend_value"] = fundamentals["lastDividendValue"]["raw"]
    
    # Last dividend date
    if fundamentals.get("lastDividendDate"):
        analysis["last_dividend_date"] = fundamentals["lastDividendDate"]["raw"]
    
    # Add more analysis criteria here based on available fundamental metrics
    
    return analysis

print(analyze_company_Statistics(get_company_Statistics("WIPRO.NS")))

def recommend_Stock_Statistics(analysis):
    recommended_stocks = []
    
    # Example recommendation criteria - Modify or add more criteria based on your preferences
    
    # Check for positive profit margins
    if "profit_margins" in analysis and analysis["profit_margins"] > 0:
        recommended_stocks.append("Profitable Stock")
    
    # Check for low price-to-book ratio
    if "price_to_book" in analysis and analysis["price_to_book"] < 1:
        recommended_stocks.append("Undervalued Stock")
    
    # Check for positive earnings quarterly growth
    if "earnings_quarterly_growth" in analysis and analysis["earnings_quarterly_growth"] > 0:
        recommended_stocks.append("Growth Stock")
    
    # Check for high dividend yield
    if "last_dividend_value" in analysis and analysis["last_dividend_value"] > 5:
        recommended_stocks.append("Dividend Stock")
    
    # Check for low beta (less volatile)
    if "beta" in analysis and analysis["beta"] < 0.5:
        recommended_stocks.append("Stable Stock")
    
    # Check for high earnings per share
    if "earnings_per_share" in analysis and analysis["earnings_per_share"] > 10:
        recommended_stocks.append("High EPS Stock")
    
    # Check for low forward price-to-earnings ratio
    if "forward_eps" in analysis and "current_price" in analysis:
        forward_pe = analysis["current_price"] / analysis["forward_eps"]
        if forward_pe < 15:
            recommended_stocks.append("Value Stock")
    
    # Check for low enterprise-to-revenue ratio
    if "enterprise_to_revenue" in analysis and analysis["enterprise_to_revenue"] < 1:
        recommended_stocks.append("Efficient Stock")
    
    # Check for low enterprise-to-EBITDA ratio
    if "enterprise_to_ebitda" in analysis and analysis["enterprise_to_ebitda"] < 10:
        recommended_stocks.append("Profitable Operations")
    
    # Check for high return on equity
    if "return_on_equity" in analysis and analysis["return_on_equity"] > 0.15:
        recommended_stocks.append("Strong ROE Stock")
    
    # Check for low debt-to-equity ratio
    if "debt_to_equity" in analysis and analysis["debt_to_equity"] < 0.5:
        recommended_stocks.append("Low Debt Stock")
    
    # Check for positive revenue growth
    if "revenue_growth" in analysis and analysis["revenue_growth"] > 0:
        recommended_stocks.append("Growing Revenue Stock")
    
    # Add more recommendation criteria based on the available analysis
    
    return recommended_stocks

def stock_recommendation(current_price, target_high_price, target_low_price, recommendation_key, number_of_analyst_opinions, profit_margins, earnings_growth, revenue_growth, beta, forward_eps):
    if recommendation_key.lower() == 'strongbuy':
        return "Strong Buy"
    elif recommendation_key.lower() == 'buy' and profit_margins > 0 and earnings_growth > 0 and revenue_growth > 0 and beta < 1 and forward_eps > 0:
        return "Buy"
    elif recommendation_key.lower() == 'hold' and number_of_analyst_opinions >= 10:
        if current_price < target_low_price:
            return "Buy"
        elif current_price > target_high_price:
            return "Sell"
        else:
            return "Hold"
    elif recommendation_key.lower() == 'underperform':
        return "Underperform"
    elif recommendation_key.lower() == 'sell':
        return "Sell"
    else:
        return "Unknown"

# recommended_stocks = recommend_stock(analysis_data)

# print("Recommended Stocks:")
# if recommended_stocks:
#     for stock in recommended_stocks:
#         print(stock)
# else:
#     print("No stocks meet the recommended criteria.")
