import pandas as pd
import numpy as np
import yfinance as yf
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import openai
import scipy.stats as stats
import math
import spacy

# Step 1: Data Collection
def get_stock_data(symbol, start_date, end_date):
    data = yf.download(symbol, start=start_date, end=end_date)
    return data

# Step 2: Data Preprocessing
def preprocess_data(data):
    # Remove any inconsistencies or outliers
    data_cleaned = data.dropna()
    # Convert data to pandas DataFrame format if necessary
    df = pd.DataFrame(data_cleaned)
    return df

# Step 3: Feature Engineering
def calculate_features(data):
    # Calculate moving averages
    data['MA50'] = data['Close'].rolling(window=50).mean()
    data['MA200'] = data['Close'].rolling(window=200).mean()

    # Calculate volatility (standard deviation of returns)
    data['Volatility'] = data['Close'].pct_change().rolling(window=20).std()

    # Calculate daily returns
    data['Returns'] = data['Close'].pct_change()

    # Calculate relative strength index (RSI)
    window_length = 14
    delta = data['Close'].diff()
    gains = delta.copy()
    losses = delta.copy()
    gains[gains < 0] = 0
    losses[losses > 0] = 0
    avg_gain = gains.rolling(window=window_length).mean()
    avg_loss = -losses.rolling(window=window_length).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    data['RSI'] = rsi

    # Calculate moving average convergence divergence (MACD)
    exp12 = data['Close'].ewm(span=12, adjust=False).mean()
    exp26 = data['Close'].ewm(span=26, adjust=False).mean()
    data['MACD'] = exp12 - exp26

    # Calculate average true range (ATR)
    high_low = data['High'] - data['Low']
    high_close = np.abs(data['High'] - data['Close'].shift())
    low_close = np.abs(data['Low'] - data['Close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = np.max(ranges, axis=1)
    atr = true_range.rolling(window=14).mean()
    data['ATR'] = atr

    # Calculate financial ratios
    data['P/E'] = data['Close'] / data['Earnings per Share']
    data['P/S'] = data['Close'] / data['Revenue per Share']

    # Calculate volume-based indicators
    data['OBV'] = np.where(data['Close'] > data['Close'].shift(), data['Volume'], -data['Volume']).cumsum()
    data['ADL'] = ((data['Close'] - data['Low']) - (data['High'] - data['Close'])) / (data['High'] - data['Low'])
    data['ADL'] = data['ADL'].fillna(0).cumsum()

    # Return the DataFrame with calculated features
    return data

# Step 4: Risk Calculation
def calculate_risk(data):
    # Calculate standard deviation
    risk_std = data['Close'].pct_change().std()

    # Calculate beta using linear regression against a benchmark index
    benchmark_data = yf.download('^GSPC', start=data.index[0], end=data.index[-1])
    returns_stock = data['Close'].pct_change().dropna()
    returns_benchmark = benchmark_data['Close'].pct_change().dropna()
    model = LinearRegression()
    model.fit(returns_benchmark.values.reshape(-1, 1), returns_stock.values.reshape(-1, 1))
    beta = model.coef_[0][0]

    # Calculate Value at Risk (VaR) at a specified confidence level (e.g., 95%)
    confidence_level = 0.95
    returns_sorted = returns_stock.sort_values()
    var = -returns_sorted.quantile(1 - confidence_level)

    # Calculate Conditional Value at Risk (CVaR) at the same confidence level
    cvar = -returns_sorted[returns_sorted <= var].mean()

    # Calculate Sharpe Ratio
    risk_free_rate = 0.02  # Example risk-free rate
    excess_returns = returns_stock - risk_free_rate
    sharpe_ratio = (excess_returns.mean() / excess_returns.std()) * math.sqrt(252)  # Assuming 252 trading days in a year

    # Calculate Maximum Drawdown
    cumulative_returns = (1 + returns_stock).cumprod()
    peak = cumulative_returns.cummax()
    drawdown = (cumulative_returns - peak) / peak
    max_drawdown = drawdown.min()

    # Calculate Sortino Ratio
    downside_returns = returns_stock.copy()
    downside_returns[downside_returns > 0] = 0  # Consider only negative returns
    downside_std = downside_returns.std()
    sortino_ratio = (excess_returns.mean() / downside_std) * math.sqrt(252)  # Assuming 252 trading days in a year
    
    # Recommendation based on risk metrics and additional features
    if sharpe_ratio > 0 and beta > 0:
        if var < 0.05 and max_drawdown < 0.1 and sortino_ratio > 1.0:
            recommendation = 'Strong Buy' 
        elif var < 0.1 and max_drawdown < 0.2 and sortino_ratio > 0.8:
            recommendation = 'Buy' 
        else:
            recommendation = 'Hold' 
    else:
        recommendation = 'Do Not Buy'  


    return {'Risk Standard Deviation': risk_std, 'Beta': beta, 'VaR': var, 'CVaR': cvar, 'Sharpe Ratio': sharpe_ratio, 'Max Drawdown': max_drawdown, 'Sortino Ratio': sortino_ratio , 'Recommendation': recommendation}

# Step 5: NLP Analysis
def perform_nlp_analysis(text):
    # Load the spaCy model for sentiment analysis
    nlp = spacy.load('en_core_web_md')

    # Process the text with the spaCy model
    doc = nlp(text)

    # Determine the sentiment based on the sentiment scores of the individual tokens
    sentiment_score = sum([token.sentiment for token in doc]) / len(doc)

    # Classify the sentiment as positive, negative, or neutral based on the sentiment score
    if sentiment_score >= 0.2:
        sentiment_label = 'Positive'
    elif sentiment_score <= -0.2:
        sentiment_label = 'Negative'
    else:
        sentiment_label = 'Neutral'

    return sentiment_label, sentiment_score

# Step 6: Model Development
def build_model(features, target):
    # Build models using appropriate algorithms (e.g., linear regression, time series analysis, ML algorithms, neural networks, etc.)
    model = LinearRegression()
    model.fit(features, target)
    return model

# Step 7: Visualization and Reporting
def visualize_data(data):
    # Visualize the data using plots, charts, or other visualization techniques
    fig, axes = plt.subplots(2, 1, figsize=(10, 8))

    # Plot the stock price
    axes[0].plot(data.index, data['Close'], linewidth=2)
    axes[0].set_xlabel('Date')
    axes[0].set_ylabel('Price')
    axes[0].set_title('Stock Price')

    # Plot the moving averages
    axes[1].plot(data.index, data['MA50'], linewidth=2, label='MA50')
    axes[1].plot(data.index, data['MA200'], linewidth=2, label='MA200')
    axes[1].set_xlabel('Date')
    axes[1].set_ylabel('Moving Averages')
    axes[1].set_title('Moving Averages')
    axes[1].legend()

    plt.tight_layout()
    plt.show()


    # Generate reports or dashboards summarizing the risk analysis
    # You can use libraries like Pandas or HTML/CSS templates to create reports


if __name__ == '__main__':
    pass
