# # Import libraries
# import pandas as pd
# import numpy as np
# import yfinance as yf
# # import talib as ta

# # Define parameters
# start_date = '2021-01-01' # Start date of historical data
# end_date = '2021-12-31' # End date of historical data
# symbols = ['AAPL', 'MSFT', 'AMZN', 'GOOG', 'FB'] # List of stock symbols to consider
# lookback = 14 # Number of days to calculate indicators
# atr_factor = 2 # Factor to multiply average true range for stop loss and target
# risk_per_trade = 0.01 # Percentage of capital to risk per trade

# # Download historical data
# data = yf.download(symbols, start=start_date, end=end_date, group_by='ticker', auto_adjust=True)

# # Calculate indicators
# for symbol in symbols:
#     data[symbol, 'ATR'] = ta.ATR(data[symbol, 'High'], data[symbol, 'Low'], data[symbol, 'Close'], timeperiod=lookback) # Average true range
#     data[symbol, 'SMA'] = ta.SMA(data[symbol, 'Close'], timeperiod=lookback) # Simple moving average
#     data[symbol, 'RSI'] = ta.RSI(data[symbol, 'Close'], timeperiod=lookback) # Relative strength index

# # Define entry and exit rules
# for symbol in symbols:
#     data[symbol, 'Buy'] = np.where((data[symbol, 'Close'] > data[symbol, 'SMA']) & (data[symbol, 'RSI'] < 30), 1, 0) # Buy when price is above SMA and RSI is below 30
#     data[symbol, 'Sell'] = np.where((data[symbol, 'Close'] < data[symbol, 'SMA']) & (data[symbol, 'RSI'] > 70), -1, 0) # Sell when price is below SMA and RSI is above 70
#     data[symbol, 'Stop Loss'] = data[symbol, 'Close'] - atr_factor * data[symbol, 'ATR'] # Stop loss is below the entry price by ATR factor
#     data[symbol, 'Target'] = data[symbol, 'Close'] + atr_factor * data[symbol, 'ATR'] # Target is above the entry price by ATR factor

# # Backtest the strategy
# capital = 100000 # Initial capital
# positions = pd.DataFrame(index=data.index) # DataFrame to store positions
# pnl = pd.DataFrame(index=data.index) # DataFrame to store profit and loss

# for symbol in symbols:
#     positions[symbol] = 0 # Initialize positions to zero
#     pnl[symbol] = 0 # Initialize pnl to zero

#     for i in range(1, len(data)):
#         if positions[symbol].iloc[i-1] == 0: # If no position in the previous day
#             if data[symbol, 'Buy'].iloc[i] == 1: # If buy signal today
#                 positions[symbol].iloc[i] = capital * risk_per_trade / data[symbol, 'ATR'].iloc[i] # Calculate number of shares to buy based on risk per trade and ATR
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i] * (data[symbol, 'Close'].iloc[i] - data[symbol, 'Open'].iloc[i]) # Calculate pnl for the day based on entry at open and exit at close
#             elif data[symbol, 'Sell'].iloc[i] == -1: # If sell signal today
#                 positions[symbol].iloc[i] = -capital * risk_per_trade / data[symbol, 'ATR'].iloc[i] # Calculate number of shares to sell based on risk per trade and ATR
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i] * (data[symbol, 'Open'].iloc[i] - data[symbol, 'Close'].iloc[i]) # Calculate pnl for the day based on entry at open and exit at close
        
#         elif positions[symbol].iloc[i-1] > 0: # If long position in the previous day
#             if data[symbol, 'Low'].iloc[i] < data[symbol, 'Stop Loss'].iloc[i-1]: # If stop loss hit today
#                 positions[symbol].iloc[i] = 0 # Exit the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i-1] * (data[symbol, 'Stop Loss'].iloc[i-1] - data[symbol, 'Open'].iloc[i]) # Calculate pnl for the day based on exit at stop loss and entry at open
#             elif data[symbol, 'High'].iloc[i] > data[symbol, 'Target'].iloc[i-1]: # If target hit today
#                 positions[symbol].iloc[i] = 0 # Exit the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i-1] * (data[symbol, 'Target'].iloc[i-1] - data[symbol, 'Open'].iloc[i]) # Calculate pnl for the day based on exit at target and entry at open
#             else: # If neither stop loss nor target hit today
#                 positions[symbol].iloc[i] = positions[symbol].iloc[i-1] # Carry forward the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i] * (data[symbol, 'Close'].iloc[i] - data[symbol, 'Open'].iloc[i]) # Calculate pnl for the day based on entry and exit at open and close
        
#         elif positions[symbol].iloc[i-1] < 0: # If short position in the previous day
#             if data[symbol, 'High'].iloc[i] > data[symbol, 'Stop Loss'].iloc[i-1]: # If stop loss hit today
#                 positions[symbol].iloc[i] = 0 # Exit the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i-1] * (data[symbol, 'Open'].iloc[i] - data[symbol, 'Stop Loss'].iloc[i-1]) # Calculate pnl for the day based on exit at stop loss and entry at open
#             elif data[symbol, 'Low'].iloc[i] < data[symbol, 'Target'].iloc[i-1]: # If target hit today
#                 positions[symbol].iloc[i] = 0 # Exit the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i-1] * (data[symbol, 'Open'].iloc[i] - data[symbol, 'Target'].iloc[i-1]) # Calculate pnl for the day based on exit at target and entry at open
#             else: # If neither stop loss nor target hit today
#                 positions[symbol].iloc[i] = positions[symbol].iloc[i-1] # Carry forward the position
#                 pnl[symbol].iloc[i] = positions[symbol].iloc[i] * (data[symbol, 'Open'].iloc[i] - data[symbol, 'Close'].iloc[i]) # Calculate pnl for the day based on entry and exit at open and close

# # Calculate total pnl and performance metrics
# total_pnl = pnl.sum(axis=1) # Sum up pnl across symbols for each day
# total_pnl.cumsum().plot() # Plot cumulative pnl over time
# print('Total PnL: ', total_pnl.sum()) # Print total pnl
# print('Sharpe Ratio: ', total_pnl.mean() / total_pnl.std()) # Print sharpe ratio
# print('Maximum Drawdown: ', (total_pnl.cumsum() - total_pnl.cumsum().expanding().max()).min()) # Print maximum drawdown
